/*

public class CheckSum {

    public static int calculate(int number) {
        int result = 0;

        if (number != 0)
            return (result + calculate(number%10));
        else
            return 0;

    }

    public static void main(String[] args) {
        System.out.println(calculate(1234));
    }
}*/
